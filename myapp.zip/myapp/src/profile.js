import React from 'react';
import './profile.css';

function profile() {
    return (
<div class="container">
        <h2>Edit Your Profile</h2>
        <form action="update_profile.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username"  required/>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email"  required/>
            </div>
            <div class="form-group">
                <label for="bio">Bio:</label>
                <textarea id="bio" name="bio" rows="4">This is a sample bio.</textarea>
            </div>
            <div class="form-group">
                <label for="profile_picture">Profile Picture:</label>
                <input type="file" id="profile_picture" name="profile_picture"/>
            </div>
            <button type="submit" class="btn">Save Changes</button>
        </form>
    </div>
    );
}

export default profile;