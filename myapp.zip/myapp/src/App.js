import logo from './logo.svg';
import './App.css';
import login from './login.js';
import profile from './profile.js';


function App() {
  return (
    <div class="registration-container">
    <h2>Register</h2>
    <form id="registrationForm">
        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required/>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required/>
        </div>
        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required/>
        </div>
        <div class="form-group">
            <input type="submit" value="Register"/>
        </div>
        <div class="error-message" id="error-message">Please fill out all fields correctly.</div>
    </form>
</div>
  );
}

//export default App;
//export default login;
export default profile;